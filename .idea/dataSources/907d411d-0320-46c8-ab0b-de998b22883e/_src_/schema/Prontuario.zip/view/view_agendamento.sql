CREATE VIEW view_agendamento AS
  SELECT
    `a`.`id`                AS `id`,
    `a`.`status`            AS `status`,
    `a`.`paciente_id`       AS `paciente_id`,
    `a`.`medico_id`         AS `medico_id`,
    `a`.`hora`              AS `hora`,
    `a`.`data`              AS `data`,
    `m`.`nome`              AS `nome_medico`,
    `m`.`crm`               AS `crm`,
    `pa`.`nome`             AS `nome_paciente`,
    `sv`.`altura`           AS `altura`,
    `sv`.`Data`             AS `data_sinais_vitais`,
    `sv`.`dor`              AS `dor`,
    `sv`.`imc`              AS `imc`,
    `sv`.`peso`             AS `peso`,
    `sv`.`temperatura`      AS `temperatura`,
    `h`.`hipotese`          AS `hipotese`,
    `h`.`obs`               AS `obs`,
    `p`.`prescricao`        AS `prescricao`,
    `ev`.`evolucao`         AS `evolucao`,
    `at`.`atestado`         AS `atestado`,
    `ad`.`alergias`         AS `alergias`,
    `ad`.`diabetes`         AS `diabetes`,
    `ad`.`gravides`         AS `gravides`,
    `ad`.`hepatite`         AS `hepatite`,
    `ad`.`pr_articulares`   AS `pr_articulares`,
    `ad`.`pr_cariacos`      AS `pr_cariacos`,
    `ad`.`pr_cicatrizacao`  AS `pr_cicatrizacao`,
    `ad`.`pr_renais`        AS `pr_renais`,
    `ad`.`pr_gastricos`     AS `pr_gastricos`,
    `ad`.`pr_respiratorios` AS `pr_respiratorios`,
    `ad`.`queixa_principal` AS `queixa_principal`,
    `ad`.`ultiliza_med`     AS `ultiliza_med`
  FROM ((((((((`Prontuario`.`Agendamento` `a` LEFT JOIN `Prontuario`.`sinais_vitais` `sv`
      ON ((`a`.`id` = `sv`.`agendamento_id`))) LEFT JOIN `Prontuario`.`hiposete` `h`
      ON ((`a`.`id` = `h`.`agendamento_id`))) LEFT JOIN `Prontuario`.`prescricao` `p`
      ON ((`a`.`id` = `p`.`agendamento_id`))) LEFT JOIN `Prontuario`.`evolucao` `ev`
      ON ((`a`.`id` = `ev`.`agendamento_id`))) LEFT JOIN `Prontuario`.`atestado` `at`
      ON ((`a`.`id` = `at`.`agendamento_id`))) LEFT JOIN `Prontuario`.`Atendimento` `ad`
      ON ((`a`.`id` = `ad`.`agendamento_id`))) JOIN `Prontuario`.`Medicos` `m` ON ((`a`.`medico_id` = `m`.`id`))) JOIN
    `Prontuario`.`Paci` `pa` ON ((`a`.`paciente_id` = `pa`.`id`)));
